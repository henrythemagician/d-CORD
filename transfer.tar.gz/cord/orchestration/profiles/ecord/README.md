# E-CORD Profile

This repository is intended to host XOS Models definitions and XOS GUI Extensions that are horizontal to the profile and not tight to a single service.

It contains models and GUIs for both `ecord-local` and `ecord-global` profiles.

## Stay tuned. More documentation coming soon!
