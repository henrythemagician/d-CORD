# M-CORD Profile

This repository is intended to host XOS Models definitions and XOS GUI Extensions that are horizontal to the profile and not tight to a single service.

Stay tuned. More documentation coming soon!
