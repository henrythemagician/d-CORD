## VNOD Local Service

This repository contains components needed for the XOS VNOD Local service

Sub-directories

* xos: A service definition for the VNOD Local. This follows the XOS component design for onboarding.

