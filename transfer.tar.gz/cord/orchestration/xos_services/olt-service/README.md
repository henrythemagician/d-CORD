XOS service for ONOS OLT app
